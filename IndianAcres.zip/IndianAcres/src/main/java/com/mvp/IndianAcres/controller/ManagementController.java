package com.mvp.IndianAcres.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mvp.IndianAcersBackend.dao.propertiesDAO;
import com.mvp.IndianAcersBackend.dto.properties;

@Controller
@RequestMapping("/manage")
public class ManagementController {
	
	@Autowired
	private propertiesDAO propertiesDAO;
	

	@RequestMapping(value = "/properties", method = RequestMethod.GET)
	public ModelAndView showManageproprties(@RequestParam(name="operation",required=false)String operation) {

		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "properties Management");
		mv.addObject("userClickManageproperties", true);

		properties nproperties = new properties();

		nproperties.setSupplierId(1);
		nproperties.setActive(true);
		nproperties.setCategoryId(1);
		mv.addObject("properties", nproperties);
		
		
		return mv;
		}
		
	
	
	//handling properties submission
	@RequestMapping(value = "/properties", method = RequestMethod.POST)
	@Transactional
	public String handlePropertiesSubmission(@ModelAttribute("properties") properties mproperties)
	
	{
		propertiesDAO.add(mproperties);
		
		return "redirect:/manage/properties?operation=properties";
	}
}