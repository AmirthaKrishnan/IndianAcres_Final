package com.mvp.IndianAcres.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mvp.IndianAcersBackend.dao.CategoryDAO;
import com.mvp.IndianAcersBackend.dao.propertiesDAO;
import com.mvp.IndianAcersBackend.dto.properties;;

@Controller
public class PageController {
	private static final Logger Logger = LoggerFactory.getLogger(PageController.class);
	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private propertiesDAO propertiesDAO;

	@RequestMapping(value = { "/", "/home", "/index" })
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Home");

		Logger.info("Inside PageController index method - INFO");
		Logger.debug("Inside PageController index method - DEBUG");

		// passing the list of categories
		mv.addObject("categories", categoryDAO.list());

		return mv.addObject("userClickHome", true);

	}

	@RequestMapping(value = "/about")
	public ModelAndView about() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "About us");
		return mv.addObject("userClickAbout", true);
	}

	@RequestMapping(value = "/contact")
	public ModelAndView contact() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Contact us");
		return mv.addObject("userClickContact", true);
	}

	@RequestMapping(value = "/properties")
	public ModelAndView properties() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "properties");
		return mv.addObject("userClickproperties", true);
	}

	@RequestMapping(value = "/login")
	public ModelAndView Buyproperties() {
		ModelAndView mv = new ModelAndView("login");
		mv.addObject("title", "login");
		return mv.addObject("userClickLogin", true);
	}

	@RequestMapping(value = "/EmiCalculator")
	public ModelAndView Emi() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Emi");
		return mv.addObject("userClickEmi", true);
	}

	/*
	 * Viewing a single properties
	 */

	@RequestMapping(value = "/show/{id}/properties")
	public ModelAndView showSingleproperties(@PathVariable int id) {

		ModelAndView mv = new ModelAndView("page");

		properties properties = propertiesDAO.get(id);

		// update the view count
		properties.setViews(properties.getViews() + 1);
		propertiesDAO.update(properties);

		mv.addObject("title", properties.getName());
		mv.addObject("properties", properties);

		return mv.addObject("usershowSingleproperties", true);
	}
}