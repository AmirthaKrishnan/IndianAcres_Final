package com.mvp.IndianAcres.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mvp.IndianAcersBackend.dao.CityDAO;
import com.mvp.IndianAcersBackend.dao.propertiesDAO;
import com.mvp.IndianAcersBackend.dto.City;
import com.mvp.IndianAcersBackend.dto.properties;

@Controller
@RequestMapping("/json/data")
@Transactional
public class JsonDataController {

	@Autowired
	private propertiesDAO propertiesDAO;

	@RequestMapping("/all/properties")
	@ResponseBody
	@Transactional
	public List<properties> getAllproperties() {

		return propertiesDAO.listActiveproperties();

	}

	@Autowired
	private CityDAO CityDAO;

	@RequestMapping("/all/City")
	@ResponseBody
	@Transactional
	public List<City> getAllCity() {

		return CityDAO.listActiveCity();
	}

	@RequestMapping("/category/{id}/properties")
	@ResponseBody
	public List<properties> getpropertiessByCategory(@PathVariable int id) {

		return propertiesDAO.listActivepropertiesByCategory(id);

	}
}
