package com.mvp.IndianAcersBackend.dao;

import java.util.List;

import com.mvp.IndianAcersBackend.dto.Category;

public interface CategoryDAO {

	boolean add(Category category);

	List<Category> list();

	Category get(int id);

	Object update(Category category);

	Object delete(Category category);

}
