package com.mvp.IndianAcersBackend.dao;

import java.util.List;

import com.mvp.IndianAcersBackend.dto.City;

public interface CityDAO {

	City get(int cityId);

	List<City> list();

	List<City> selectActiveCity();

	List<City> listActiveCity();

}