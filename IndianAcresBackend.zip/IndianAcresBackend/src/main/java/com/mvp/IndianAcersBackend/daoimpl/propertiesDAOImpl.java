package com.mvp.IndianAcersBackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mvp.IndianAcersBackend.dao.propertiesDAO;
import com.mvp.IndianAcersBackend.dto.properties;

@Repository("propertiesDAO")
@Transactional
public class propertiesDAOImpl implements propertiesDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private String selectActiveproperties;

	/*
	 * SINGLE
	 */

	@Override
	public properties get(int propertiesId) {
		try {
			return sessionFactory.getCurrentSession().get(properties.class, Integer.valueOf(propertiesId));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	/*
	 * LIST
	 */

	@Override

	public List<properties> list() {
		return sessionFactory.getCurrentSession().createQuery("FROM properties", properties.class).getResultList();
	}

	/*
	 * INSERT
	 */
	@Override
	public boolean add(properties properties) {
		try {
			sessionFactory.getCurrentSession().persist(properties);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	/*
	 * UPDATE
	 */
	@Override
	public boolean update(properties properties) {
		try {
			sessionFactory.getCurrentSession().update(properties);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	/*
	 * DELETE
	 */
	@Override
	public boolean delete(properties properties) {
		try {

			properties.setActive(false);
			// call the update method
			return this.update(properties);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	@Override
	public List<properties> listActiveproperties() {
		String selectActiveproperties = "FROM properties WHERE active = :active";
		return sessionFactory.getCurrentSession().createQuery(selectActiveproperties, properties.class)
				.setParameter("active", true).getResultList();
	}

	@Override
	public List<properties> listActivepropertiesByCategory(int categoryId) {
		String selectActivepropertiesByCategory = "FROM properties WHERE active = :active AND categoryId = :categoryId";
		return sessionFactory.getCurrentSession().createQuery(selectActivepropertiesByCategory, properties.class)
				.setParameter("active", true).setParameter("categoryId", categoryId).getResultList();
	}

	@Override
	public List<properties> getLatestActiveproperties(int count) {
		return sessionFactory.getCurrentSession()
				.createQuery("FROM properties WHERE active = :active ORDER BY id", properties.class)
				.setParameter("active", true).setFirstResult(0).setMaxResults(count).getResultList();
	}

	@Override
	public List<properties> getallpropertiesbysearch(String value) {
		return sessionFactory.getCurrentSession()
				.createQuery("from properties where city like '%" + value + "%'", properties.class)
				.setParameter("active", true).setFirstResult(0).getResultList();
	}

}