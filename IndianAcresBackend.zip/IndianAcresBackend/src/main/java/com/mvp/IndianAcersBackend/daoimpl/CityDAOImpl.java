package com.mvp.IndianAcersBackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mvp.IndianAcersBackend.dao.CityDAO;
import com.mvp.IndianAcersBackend.dto.City;
import com.mvp.IndianAcersBackend.dto.properties;

@Repository("CityDAO")
@Transactional
public class CityDAOImpl implements CityDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public City get(int CityId) {
		try {
			return sessionFactory.getCurrentSession().get(City.class, Integer.valueOf(CityId));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	/*
	 * LIST
	 */

	@Override
	public List<City> list() {
		return sessionFactory.getCurrentSession().createQuery("FROM City", City.class).getResultList();
	}

	@Override
	public List<City> listActiveCity() {
		String selectActiveCity = "FROM City WHERE is_active = :active";
		return sessionFactory.getCurrentSession().createQuery(selectActiveCity, City.class).setParameter("active", true)
				.getResultList();

	}

	@Override
	public List<City> selectActiveCity() {
		// TODO Auto-generated method stub
		return null;
	}

}
