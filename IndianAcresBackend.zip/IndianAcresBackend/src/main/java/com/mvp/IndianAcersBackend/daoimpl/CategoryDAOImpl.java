package com.mvp.IndianAcersBackend.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mvp.IndianAcersBackend.dao.CategoryDAO;
import com.mvp.IndianAcersBackend.dto.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {

	// @Autowired
	// private SessionFactory sessionFactory;

	private static List<Category> Categories = new ArrayList<>();

	static {
		Category category = new Category();
		category.setId(1);
		category.setName("Buy");
		category.setDescription("Buy Home/Land");
		category.setImageURL("1.jpg");
		Categories.add(category);

		// Two Category
		category = new Category();
		category.setId(2);
		category.setName("Rent");
		category.setDescription("Remt a house");
		category.setImageURL("2.jpg");
		Categories.add(category);

		// third CAtegory
		category = new Category();
		category.setId(3);
		category.setName("Offer");
		category.setDescription("Offers Avaliable");
		category.setImageURL("3.jpg");
		Categories.add(category);
	}

	@Override
	public List<Category> list() {
		// TODO Auto-generated method stub
		return Categories;
	}

	@Override
	@Transactional
	public boolean add(Category category) {

		try {
			// add Category
			// sessionFactory.getCurrentSession().persist(category);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();

		}
		return false;
	}

	@Override
	public Category get(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object update(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object delete(Category category) {
		// TODO Auto-generated method stub
		return null;
	}
}
