package com.mvp.IndianAcersBackend.dao;

import java.util.List;

import com.mvp.IndianAcersBackend.dto.properties;

public interface propertiesDAO {

	properties get(int propertiesId);

	List<properties> list();

	boolean add(properties properties);

	boolean update(properties properties);

	boolean delete(properties properties);

	// business methods
	List<properties> listActiveproperties();

	List<properties> listActivepropertiesByCategory(int categoryId);

	List<properties> getLatestActiveproperties(int count);

	List<properties> getallpropertiesbysearch(String value);

}
